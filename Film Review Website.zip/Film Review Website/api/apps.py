from django.apps import AppConfig


class apiConfig(AppConfig):
    name = 'api'
