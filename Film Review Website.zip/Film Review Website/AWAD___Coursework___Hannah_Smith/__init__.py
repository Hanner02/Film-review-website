"""
Package for AWAD___Coursework___Hannah_Smith.
"""
